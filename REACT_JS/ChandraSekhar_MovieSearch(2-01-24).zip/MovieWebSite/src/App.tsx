
import { RouterProvider, createBrowserRouter } from 'react-router-dom';
import './CSS/header.css';
import './CSS/Body.css';
import './CSS/footer.css';
import './CSS/MovieList.css';
import './CSS/actormovielist.css';
import './CSS/moviedetails.css';
import './CSS/contact.css'
import './CSS/privacy.css'
import Home from './Home';
import MovieList from './Components/MovieList';
import ActorMoviesList from './Components/ActorMoviesList';
import MovieDetails from './Components/MovieDetails';
import Contact from './Components/Contact';
import Privacy from './Components/Privacy';


const RouteApp = createBrowserRouter([
  {
    path: "/",
    element: <Home />, // Map the / path to the Home component
  },
  {
    path: "/movielist",
    element: <MovieList />,
  },
  {
    path: "/ActorsMoviesList",
    element: <ActorMoviesList />,
  },
  {
    path: "/MovieDetails",
    element: <MovieDetails />,
  },
  {
    path:"/contact",
    element: <Contact />,
  },
  {
    path:"/privacy",
    element: <Privacy />,
  },
]);

function App() {
  return (
    <>
      <RouterProvider router={RouteApp} />
    </>
  );
}

export default App;
