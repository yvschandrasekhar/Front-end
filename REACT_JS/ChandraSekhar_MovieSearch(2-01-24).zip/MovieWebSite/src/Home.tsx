import Body from "./Components/Body"
import Header from "./Components/Header"
import Footer from "./Components/Footer"
function Home() {
    return (
      <>
        <Header />
        <Body />
        <Footer />
      </>
    )
  }
   
  export default Home