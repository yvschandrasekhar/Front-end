
import React, { useEffect, useState } from "react";

interface MovieDetailsProps {
  imdbID: string;
}

const MovieDetails: React.FC<MovieDetailsProps> = ({ imdbID }) => {
  const [movieDetails, setMovieDetails] = useState<any>(null);

  useEffect(() => {
    const fetchDetails = async () => {
      try {
        const response = await fetch(`https://www.omdbapi.com/?apikey=ac4ecdb3&i=${imdbID}`);
        const data = await response.json();
        setMovieDetails(data);
      } catch (error) {
        console.error("Error fetching movie details:", error);
      }
    };

    fetchDetails();
  }, [imdbID]);

  if (!movieDetails) {
    return <div>Loading...</div>;
  }
  return (
    <div className="movie-details">
      <h1>{movieDetails.Title}</h1>
      <div className="movie-details-ele">
        <img src={movieDetails.Poster} alt={`${movieDetails.Title} Poster`} />
        <div>
          <h3>{movieDetails.Plot}</h3>
          <h3>Released: {movieDetails.Released}</h3>
          <h3>Runtime: {movieDetails.Runtime}</h3>
        </div>
      </div>
    </div>
  );
};

export default MovieDetails;

