
import { Link } from "react-router-dom";
import React, { useEffect, useRef, useState } from "react";
import MovieList from "./MovieList";
import ActorMoviesList from "./ActorMoviesList";
import MovieDetails from "./MovieDetails";

const genres = [
  "Action",
  "Comedy",
  "Drama",
  "Thriller",
  "Adventure",
  "Romance",
  "Crime",
  "ScienceFiction",
  "Fantasy",
];

const actors = [
  "Tom Hanks",
  "Leonardo DiCaprio",
  "Brad Pitt",
  "Robert De Niro",
  "George Clooney",
  "Jason Statham",
  "Matt Damon",
  "Bradley Cooper",
  "Chris Evans",
  "Liam Neeson",
  "Chris Hemsworth",
  "Tom Cruise",
  "Zoe Saldana", 
  "Mark Wahlberg",
  "Matthew McConaughey",
  "Dwayne Johnson",
];

const Header = () => {
  const [search, setSearch] = useState(false);
  const [selectedGenre, setSelectedGenre] = useState<string | null>("");
  const [selectedActor, setSelectedActor] = useState<string | null>("");
  const [selectedMovieID, setSelectedMovieID] = useState<string | null>("");

  const inputRef = useRef<any>(null);

  const handleSearch = () => {
    setSearch(true);
  };

  const handleGenreChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedGenre = event.target.value;
    setSelectedGenre(selectedGenre === "TOP GENERES" ? null : selectedGenre);
    setSelectedActor(null); 
    setSelectedMovieID(null); 
  };

  const handleActorChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedActor = event.target.value;
    setSelectedActor(selectedActor === "TOP ACTORS" ? null : selectedActor);
    setSelectedGenre(null); 
    setSelectedMovieID(null); 
  };

  const handleBlogClick = () => {
    setSelectedMovieID("tt3896198");
    setSelectedGenre(null);
    setSelectedActor(null);
    setSearch(false);
  };

  useEffect(() => {
    if (search) {
      if (inputRef.current) {
        inputRef.current.focus();
      }
    }
  }, [search]);

  return (
    <div className="header">
      <Link to={"/"}>
        <div className="headerLink">
          <img src="src/pics/MOVIE.jpg" />
          <h2>
            Pic a Movie for me.Com <br></br>
            <small>the search is over</small>
          </h2>
        </div>
      </Link>
      <div className="header-ele">
        <p>MOVIE PICKER</p>
        <p>|</p>
        <select className="select1" onChange={handleGenreChange}>
          <option>TOP GENERES</option>
          {genres.map((genre) => (
            <option key={genre}>{genre}</option>
          ))}
        </select>
        <p>|</p>
        <select className="select2" onChange={(e) => handleActorChange(e)}>
          <option>TOP ACTORS</option>
          {actors.map((actor) => (
            <option key={actor}>{actor}</option>
          ))}
        </select>
        <p>|</p>
        <p onClick={handleBlogClick} className="blog">
          BLOG
        </p>
        <div className="header-icons">
          <i
            onClick={handleSearch}
            className="fa-solid sp fs-14 fa-magnifying-glass text-white"
          ></i>
          <a
            target="_blank"
            href="https://www.facebook.com/PickAMovieForMeOfficial/"
          >
            <i className="fa-brands fa-facebook"></i>
          </a>
          <a target="_blank" href="https://www.instagram.com/pickamovieforme/">
            <i className="fa-brands insta fa-instagram"></i>
          </a>
          <a
            target="_blank"
            href="https://www.youtube.com/channel/UCLLe8pZVF_BWnPp4-TPfsTQ"
          >
            <i className="fa-brands youtube fa-youtube"></i>
          </a>
        </div>
      </div>
      {search && (
        <div className="search-bar">
          <input type="text" placeholder="Search" ref={inputRef}/><button><i className="fa-solid fa-magnifying-glass"></i></button>
        </div>
      )}
      {selectedGenre && <MovieList genre={selectedGenre}/>}
      {selectedActor && <ActorMoviesList actor={selectedActor} />}
      {selectedMovieID && <MovieDetails imdbID={selectedMovieID} />}
    </div>
  );
};

export default Header;

