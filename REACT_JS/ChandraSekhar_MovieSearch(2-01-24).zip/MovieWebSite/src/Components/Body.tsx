import { useState , useEffect , useRef } from "react"

function Body()
{
    const[click , setClick] = useState(false)
    const handleClick=()=>{
        setClick(true)
    }
    const inputRef = useRef<any>(null);
    useEffect(() => {
        if (click) {
            if(inputRef.current){
                inputRef.current.focus()
            }
        }
    }, [click]);
    return(
        <>
        <div className="mainbody">
            <img src="src/pics/movb.jpg"/>
            <div className="mainbody-text">
                <h1>MOVIE RECOMMENDATION ENGINE</h1>
                <h3>You can't decide between thousands of movies available for streaming?</h3>
                <h3>Answer 6 questions and let us do the work!</h3>
                <button className="btn1" onClick={handleClick}>Start Now</button>
            </div>
            {click && (
                    <div className="search" >
                        <input type="text" placeholder="1.How are you today" ref={inputRef}/>&nbsp;<button className="btn2" onClick={()=>setClick(false)}><i className="fa-solid fa-x fa-xl"></i></button>
                        <div className="emojis">
                            <div><i className="fa-regular fa-face-smile fa-2xl"></i></div>
                            <div><i className="fa-regular fa-face-sad-tear fa-2xl"></i></div>
                            <div><i className="fa-regular fa-face-meh fa-2xl"></i></div>
                        </div>
                    </div>
            )}
        </div>
        </>
    )
}
export default Body