
import React, { useEffect, useState } from "react";

interface MovieListProps {
  genre: string | null;
}

interface Movie {
  imdbID: string;
  Title: string;
  Poster: string;
  Year: string;
}

const MovieList: React.FC<MovieListProps> = ({ genre }) => {
  const [movies, setMovies] = useState<Movie[]>([]);

  useEffect(() => {
    if (genre) {
      const fetchMovies = async () => {
        try {
          const response = await fetch(`https://www.omdbapi.com/?apikey=ac4ecdb3&s=${genre}`);
          const data = await response.json();
          setMovies(data.Search || []);
        } catch (error) {
          console.error("Error fetching movies:", error);
        }
      };

      fetchMovies();
    }
  }, [genre]);

  if (!genre) {
    return null; 
  }

  return (
    <div className="movie-list">
      <h3>Movies in {genre}</h3>
      <ul>
        {movies.map((movie) => (
          <li key={movie.imdbID}>
            <img src={movie.Poster} alt={movie.Title} />
            <div>
              <h4>{movie.Title}</h4>
              <p>Year: {movie.Year}</p>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default MovieList;