// ActorMoviesList.tsx

import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

interface ActorMoviesListProps {
  actor: string;
}

interface Movie {
  imdbID: string;
  Title: string;
  Poster: string;
}

const ActorMoviesList: React.FC<ActorMoviesListProps> = ({ actor }) => {
  const [movies, setMovies] = useState<Movie[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(`https://www.omdbapi.com/?apikey=ac4ecdb3&s=${actor}`);
        const data = await response.json();
        setMovies(data.Search || []);
      } catch (error) {
        console.error("Error fetching movies:", error);
      }
    };

    fetchData();
  }, [actor]);

  return (
    
    <div className="actor-movies-list">
      <h1>Movies featuring {actor}</h1>
      <div className="movies-container">
        {movies.map((movie) => (
          <div key={movie.imdbID} className="movie-item">
            <img src={movie.Poster} alt={`${movie.Title} Poster`} />
            <h3>{movie.Title}</h3>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ActorMoviesList;
