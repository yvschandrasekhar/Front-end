
import MyProducts from './MyProducts'

function App() {
  

  return (
    <>
      <MyProducts />
    </>
  )
}

export default App
