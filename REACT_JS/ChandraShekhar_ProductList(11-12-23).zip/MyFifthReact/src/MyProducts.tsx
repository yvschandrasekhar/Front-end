import axios from "axios"
import { useEffect ,useState } from "react"
import './MyProd.css'
interface Productuser{
    
        brand: string,
        category: string,
        description: string,
        id: number,
        images: string[],
        price: number,
        rating : number,
        stock: number,
        thumbnail: string,
        title: string
    
}
function MyProducts(){

    const [data,setData] = useState<Productuser[]>([])


    useEffect(()=>{
        axios.get('https://dummyjson.com/products')
        .then((res) => setData(res.data.products))
        .catch((err) => console.log(err))
        
        
    },[])

    return(
        <>
            <div className="container">
                <div className="mt-3">
                    <h2>Displaying the Product List</h2>
                    <table>
                        <tr>
                            <th>Brand</th>
                            <th>category</th>
                            <th>Description</th>
                            <th>id</th>
                            <th>images</th>
                            <th>Price</th>
                            <th>Rating</th>
                            <th>Stock</th>
                            <th>Thumbnail</th>
                        </tr>
                        {
                            data.map((user )=>{
                                return<tr key={user.id}>
                                <td>{user.brand}</td>
                                <td>{user.category}</td>
                                <td>{user.description}</td>
                                <td>{user.id}</td>
                                <td>{user.images.map((image, index) => (
                                            <img
                                            src={image}
                                            alt={`${user.title || 'Product'} - Image ${index + 1}`}
                                            key={index}
                                            />
                                        ))}</td>
                                <td>{user.price}</td>
                                <td>{user.rating}</td>
                                <td>{user.stock}</td>
                                <td>{user.thumbnail}</td>
                                <td>{user.title}</td>
                            </tr>
                                
                            })
                        }
                    </table>
                </div>
            </div>
        </>
    )
}
export default MyProducts