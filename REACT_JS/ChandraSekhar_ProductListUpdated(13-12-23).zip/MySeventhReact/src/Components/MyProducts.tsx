import axios from "axios"
import { useState ,useEffect} from "react"
import { Link } from "react-router-dom"
import "./MyProducts.css"
interface type{
    id:number,
    title:string,
    price:number,
    description:string,
    discountPercentage:number,
    rating:number,
    stock:number,
    brand:string,
    thumbnail:string
}

const MyProducts = () =>{

    const [product,setproduct]=useState<type[]>([])

    useEffect (()=>{
        axios.get('https://dummyjson.com/products')
        .then(resp =>{
            setproduct(resp.data.products)
        })
    },[])

    return(
        <>
            <div className="main">
                <div className="main-item">
                    {product.map((prod)=>(
                    
                    <Link key={prod.id} to={`about/${prod.id}`} state={prod}>
                    <div className="box" >
                
                        <img className="box-img" src={prod.thumbnail} alt="" />
                        <h2>{prod.title}</h2>
                
                    </div>
                    </Link>
                    
                    ))}
                </div>
            </div>
        </>
    )
}
export default MyProducts;