import { Link, useLocation } from "react-router-dom"
import "./ProductDetails.css"


const ProductDetails = () =>{

    const location=useLocation();
    const state=location.state;
    console.log(state);

    const handleAddProduct = ()=>{

        if(!localStorage.getItem('cartArray')){
            localStorage.setItem('cartArray' , '[]');
        }else{
            const cartArray =JSON.parse( localStorage.getItem('cartArray') || '[]');
            cartArray.push(state);
            localStorage.setItem('cartArray' , JSON.stringify(cartArray));
        }



    }
    
    
    return(
        <>
        <Link to="/" ><button className="btn-prod">MyProducts</button></Link>
        <div className="main1">
            <div className="image">
                <img src={state.thumbnail} alt="" className="img1" />
            </div>
            <div className="details">
                <h3 className="h3">{state.title}</h3>
                <p className="p">{state.description}</p>
                <p className="p">Brand : {state.brand}</p>
                <h1 className="h3">Price  : {state.price}</h1>
                <p className="p">Discount : {state.discountPercentage} %</p>
                <p className="p">Rating : {state.rating}</p>
                <p className="p">Stock : {state.stock}</p>
                <Link to="/cart" state={state}><button className="btn1"  onClick={handleAddProduct} >Add to Cart</button></Link>
            </div>
        </div>
        </>
    )
}
export default ProductDetails;