import { useLocation } from "react-router-dom";
import { Link } from "react-router-dom";
import "./Carted.css"
const arr:{
    id:number,
    title:string,
    price:number,
    description:string,
    discountPercentage:number,
    rating:number,
    stock:number,
    brand:string,
    thumbnail:string
}[]=[];

const cartArray = JSON.parse( localStorage.getItem('cartArray') || '[]');
const CartedProducts = () =>{
    const location=useLocation();
    arr.push(location.state);
    const uniqueArray = arr.filter(function(item, pos) {
        return arr.indexOf(item) == pos;
    })
    console.log(uniqueArray);
    
    

    
    

    return(
        <>
            <div>
                <Link to="/" ><button className="btn-cart">MyProducts</button></Link>
                {cartArray.map((prod:any)=>(
            <div className="main1">
            <div className="image">
                <img src={prod.thumbnail} alt="" className="img1" />
            </div>
            <div className="details">
                <h3 className="h3">{prod.title}</h3>
                <p className="p">{prod.description}</p>
                <p className="p">Brand : {prod.brand}</p>
                <h3 className="h3">Price  : {prod.price}</h3>
                <p className="p">Discount : {prod.discountPercentage} %</p>
                <p className="p">Rating : {prod.rating}</p>
                <p className="p">Stock : {prod.stock}</p>

            </div>
                    </div>
                ))}
            </div>
        </>
    )
}
export default CartedProducts;