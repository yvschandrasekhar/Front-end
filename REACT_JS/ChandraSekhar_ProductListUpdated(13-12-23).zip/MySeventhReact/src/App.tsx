import { RouterProvider, createBrowserRouter } from "react-router-dom"
import MyProducts from "./Components/MyProducts"
import ProductDetails from "./Components/ProductDetails"
import CartedProducts from "./Components/CartedProducts"

const AppRoutes=createBrowserRouter([
  {
    path:"/",
    element:<MyProducts />
  },
  {
    path:'about/:productId',
    element:<ProductDetails />,
    
  },
  {
    path:'/cart',
    element:<CartedProducts />,
  }
])


function App() {
 

  return (
    <>
     
   <RouterProvider router={AppRoutes} />
    </>
  )
}

export default App
