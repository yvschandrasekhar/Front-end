
import React, { useState } from 'react';
import './App.css';

interface Todo {
  id: number;
  text: string;
}

const App: React.FC = () => {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [newTodo, setNewTodo] = useState<string>('');
  const [editingTodo, setEditingTodo] = useState<Todo | null>(null);

  const addTodo = () => {
    if (newTodo.trim() !== '') {
      if (editingTodo) {
        
        setTodos(todos.map(todo => (todo.id === editingTodo.id ? { ...todo, text: newTodo } : todo)));
        setEditingTodo(null);
      } else {
        setTodos([...todos, { id: Date.now(), text: newTodo }]);
      }
      setNewTodo('');
    }
  };

  const editTodo = (todo: Todo) => {
    setNewTodo(todo.text);
    setEditingTodo(todo);
  };

  const deleteTodo = (id: number) => {
    setTodos(todos.filter(todo => todo.id !== id));
    setEditingTodo(null);
  };

  return (
    <div className="todo-app">
      <div className="todo-input">
        <h1>My To Do List</h1>
        <input type="text" size={80} placeholder="Add a new todo..." value={newTodo} onChange={(e) => setNewTodo(e.target.value)}/>
        <button onClick={addTodo}>{editingTodo ? 'Save' : 'Add'}</button>
      </div>
      <div>
        {todos.map((todo) => (
          <div className='task--div' key={todo.id}>
            <h3>{todo.text}</h3>
            <button onClick={() => editTodo(todo)}>Edit</button>
            <button onClick={() => deleteTodo(todo.id)}>Delete</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default App;
