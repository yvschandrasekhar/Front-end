interface ITask{
    taskName:string
}
export default ITask