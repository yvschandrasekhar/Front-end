

import axios from "axios";
import { useEffect, useState } from "react";
import './Weather.css'

const arr: string[] = [];

const Weather = () => {
    const [val, setVal] = useState("");
    const [temp, setTemp] = useState(0);
    const [wind, setWind] = useState(0);
    const [humid, setHumid] = useState(0);
    const [deg, setDeg] = useState('C');
    const [tru, setTru] = useState("");
    const [loading, setLoading] = useState(false);

    const APIKEY = "7662becb19e9a1b8407ffd017ba6744e";

    useEffect(() => {
        if (tru) {
            axios.get(`https://api.openweathermap.org/data/2.5/weather?q=${val}&appid=${APIKEY}`)
                .then((resp) => {
                    console.log(resp.data);
                    const data = resp.data;
                    setTemp(Math.round(data.main.temp - 273.15));
                    setWind(data.wind.speed);
                    setHumid(data.main.humidity);
                    setDeg('C');
                    arr.unshift(tru);
                });
        }
    }, [tru]);

    const getCurrentLocation = () => {
        setLoading(true);
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const { latitude, longitude } = position.coords;
                    axios.get(`https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&appid=${APIKEY}`)
                        .then((resp) => {
                            const data = resp.data;
                            setTemp(Math.round(data.main.temp - 273.15));
                            setWind(data.wind.speed);
                            setHumid(data.main.humidity);
                            setDeg('C');
                            setTru(data.name);
                        })
                        .finally(() => setLoading(false));
                },
                (error) => {
                    console.error("Error getting location", error);
                    setLoading(false);
                }
            );
        } else {
            console.error("Geolocation is not supported by this browser.");
            setLoading(false);
        }
    };

    const faren = () => {
        setTemp(Math.round(temp * (9 / 5) + 32));
        setDeg('F');
    };

    const celci = () => {
        setTemp(Math.round((temp - 32) * (5 / 9)));
        setDeg('C');
    };

    //const arr1 = arr.filter((item, index) => index < 5);

    return (
        <>
            <div className="main">
                <div className="display-main">
                    <div className="display-main-item-one">
                        <input size={50} type="text" placeholder="City Name" autoComplete="off" className="inputs" onChange={(e) => setVal(e.target.value)} />
                        <button className="btn-one" onClick={() => setTru(val)}>Search</button>
                        <button className="btn-four" onClick={getCurrentLocation} disabled={loading}>Get Current Location</button>
                    </div>
                    <div className="display-main-item-two">
                        <div className="display-item">
                            <div><h1>{temp} {deg}<small>o</small></h1></div>
                            <div><h2>{tru}</h2></div>
                        </div>
                        <div>
                            <div className="deg-div">
                                <button className="btn-two" onClick={() => (deg === 'C') ? faren() : null}><b>Farenite</b></button>
                                <button className="btn-three" onClick={() => (deg === 'F') ? celci() : null}><b>Celcius</b></button>
                            </div>
                            <div className="footer">
                                <h3>Humidity: {humid} percentage</h3>
                                <h3>WindSpeed: {wind} KmPh</h3>
                            </div>
                        </div>
                    </div>
                    {/* <div className="footer">
                        {arr1.map((item, index) => (
                            <div key={index} className="data-box">
                                <h4>{item}</h4>
                            </div>
                        ))}
                    </div> */}
                </div>
            </div>
        </>
    );
};

export default Weather;
