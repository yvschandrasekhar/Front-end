import MyNew from "./MyNew.tsx";
import Data from "./students.ts";
import "./App.css";
function App() {

  return (
    <>
       {<MyNew details={Data}/>}
    </>
  )
}

export default App
