const MyNew: React.FC<{details:{num: string, name: string, address: string , age: string , school: string}[]}> = (prop) => {
    const{details}=prop
    return(
        <>
        <table>
            <tr>
                <th>Stu_Num</th>
                <th>Name</th>
                <th>Location</th>
                <th>Age</th>
                <th>School</th>
            </tr>
                {details.map((item)=>(
                <>
                    <tr>
                        <td>{item.num}</td>
                        <td>{item.name}</td>
                        <td>{item.address}</td>
                        <td>{item.age}</td>
                        <td>{item.school}</td>
                    </tr>
                </>
                ))}
        </table>      
        </>
    );
};
export default MyNew;
