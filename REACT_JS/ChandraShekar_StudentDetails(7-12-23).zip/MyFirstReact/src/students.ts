const Data = [{
    num:"one",
    name: 'maxy',
    address: "address",
    age: "10",
    school : "ACB"
  },
  {
    num:"one",
    name: 'maxy',
    address: "address",
    age: "10",
    school : "ACB"
  },
  {
    num:"one",
    name: 'maxy',
    address: "address",
    age: "10",
    school : "ACB"
  }
  ]
export default Data;