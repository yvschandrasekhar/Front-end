var button = document.getElementById('btn');
button.addEventListener('click', validateForm);
function validateForm() {
    var nameInput = document.getElementById('name');
    var emailInput = document.getElementById('email');
    var ageInput = document.getElementById('age');
    var checkRadio = document.querySelector('input[name="rd"]:checked');
    var checkInput = document.getElementById('cb');
    var errorName = document.getElementById('error-name');
    errorName.innerText = '';
    var errorEmail = document.getElementById('error-mail');
    errorEmail.innerText = '';
    var errorAge = document.getElementById('error-age');
    errorAge.innerText = '';
    var errorGender = document.getElementById('error-gender');
    errorGender.innerText = '';
    var errorCheckbox = document.getElementById('error-checkbox');
    errorCheckbox.innerText = '';
    var errorMessage = document.getElementById('error-message');
    errorMessage.innerText = '';
    if (!nameInput.checkValidity()) {
        errorName.innerText = 'Name should not be empty';
    }
    else {
        errorName.innerText = '';
    }
    if (!emailInput.checkValidity()) {
        errorEmail.innerText = 'Please Enter Valid Email';
    }
    else {
        errorEmail.innerText = '';
    }
    if (!ageInput.checkValidity()) {
        errorAge.innerText = 'Please Enter your age.';
    }
    else {
        errorAge.innerText = '';
    }
    if (checkRadio == null) {
        errorGender.innerText = 'Please select gender';
    }
    else {
        errorGender.innerText = '';
    }
    if (checkInput.checked) {
        errorCheckbox.innerText = '';
    }
    else {
        errorCheckbox.innerText = 'Please Accept terms and conditions';
    }
    var formData = {
        name: nameInput.value,
        email: emailInput.value,
        age: parseInt(ageInput.value),
        gender: checkRadio.value,
        checkbox: checkInput.value,
    };
    var age = parseInt(ageInput.value, 10);
    if (isNaN(age) || age <= 0) {
        alert('age should not be zero or negative.');
        return;
    }
    if (nameInput.checkValidity() && emailInput.checkValidity() && ageInput.checkValidity() && checkRadio != null && checkInput.checked) {
        var tableBody = document.getElementById('table-body');
        var newRow = tableBody.insertRow();
        var cell1 = newRow.insertCell(0);
        var cell2 = newRow.insertCell(1);
        var cell3 = newRow.insertCell(2);
        var cell4 = newRow.insertCell(3);
        var cell5 = newRow.insertCell(4);
        cell1.textContent = formData.name;
        cell2.textContent = formData.email;
        cell3.textContent = formData.age.toString();
        cell4.textContent = formData.gender;
        cell5.textContent = formData.checkbox;
        tableBody.style.display = "inline-block";
    }
    else {
        var tableBody = document.getElementById('table-body');
        tableBody.style.display = "none";
    }
}
