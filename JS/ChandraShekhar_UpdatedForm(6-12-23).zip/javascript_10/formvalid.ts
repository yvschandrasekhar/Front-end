interface FormData {
    name: string;
    email: string;
    age: number;
    gender: string;
    checkbox: string;
}
const button = <HTMLElement>document.getElementById('btn');

button.addEventListener('click', validateForm)
function validateForm() {
    const nameInput = document.getElementById('name') as HTMLInputElement;
    const emailInput = document.getElementById('email') as HTMLInputElement;
    const ageInput = document.getElementById('age') as HTMLInputElement;
    const checkRadio = document.querySelector('input[name="rd"]:checked') as HTMLInputElement;
    const checkInput = document.getElementById('cb') as HTMLInputElement;
    
    const errorName = document.getElementById('error-name') as HTMLDivElement;
    errorName.innerText = ''; 

    const errorEmail = document.getElementById('error-mail') as HTMLDivElement;
    errorEmail.innerText = '';

    const errorAge = document.getElementById('error-age') as HTMLDivElement;
    errorAge.innerText = ''; 

    const errorGender = document.getElementById('error-gender') as HTMLDivElement;
    errorGender.innerText = ''; 

    const errorCheckbox = document.getElementById('error-checkbox') as HTMLDivElement;
    errorCheckbox.innerText = ''; 
    
    const errorMessage = document.getElementById('error-message') as HTMLDivElement;
    errorMessage.innerText = ''; 

    if(!nameInput.checkValidity()){
        errorName.innerText = 'Name should not be empty';
    }else{
        errorName.innerText = '';
    }
    if(!emailInput.checkValidity()){
        errorEmail.innerText = 'Please Enter Valid Email';
    }else{
        errorEmail.innerText = '';
    }
    if(!ageInput.checkValidity()){
        errorAge.innerText = 'Please Enter your age.';
    }else{
        errorAge.innerText = '';
    }
    if(checkRadio == null){
        errorGender.innerText = 'Please select gender';
    }else{
        errorGender.innerText = '';
    }
    if(checkInput.checked){
        errorCheckbox.innerText = '';
    }else{
        errorCheckbox.innerText = 'Please Accept terms and conditions';
    }
    const formData: any = {
        name: nameInput.value,
        email: emailInput.value,
        age: parseInt(ageInput.value),
        gender : checkRadio.value,
        checkbox: checkInput.value,
    };
    const age = parseInt(ageInput.value, 10);

    if (isNaN(age) || age <= 0) {
      alert('age should not be zero or negative.');
      return;
    }
    if(nameInput.checkValidity() && emailInput.checkValidity() && ageInput.checkValidity() && checkRadio != null && checkInput.checked ){
        const tableBody = document.getElementById('table-body') as HTMLTableSectionElement;
    
        const newRow = tableBody.insertRow();
        const cell1 = newRow.insertCell(0);
        const cell2 = newRow.insertCell(1);
        const cell3 = newRow.insertCell(2);
        const cell4 = newRow.insertCell(3);
        const cell5 = newRow.insertCell(4);
    
        cell1.textContent = formData.name;
        cell2.textContent = formData.email;
        cell3.textContent = formData.age.toString();
        cell4.textContent = formData.gender;
        cell5.textContent = formData.checkbox;
        tableBody.style.display="inline-block";
    }else{
        const tableBody = document.getElementById('table-body') as HTMLTableSectionElement;
        tableBody.style.display="none";
    }
}



