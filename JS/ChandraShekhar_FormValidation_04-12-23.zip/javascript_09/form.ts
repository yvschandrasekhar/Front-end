interface FormData {
    name: string;
    email: string;
    age: number;
}

function validateForm() {
    const nameInput = document.getElementById('name') as HTMLInputElement;
    const emailInput = document.getElementById('email') as HTMLInputElement;
    const ageInput = document.getElementById('age') as HTMLInputElement;

    const errorMessage = document.getElementById('error-message') as HTMLDivElement;
    errorMessage.innerText = '';

    if (!nameInput.checkValidity() || !emailInput.checkValidity() || !ageInput.checkValidity()) {
        errorMessage.innerText = 'Please fill out all the fields correctly.';
        return;
    }

    const formData: any = {
        name: nameInput.value,
        email: emailInput.value,
        age: parseInt(ageInput.value),
    };

    displayFormData(formData);
    clearForm();
}

function displayFormData(formData: FormData) {
    const tableBody = document.getElementById('table-body') as HTMLTableSectionElement;

    const newRow = tableBody.insertRow();
    const cell1 = newRow.insertCell(0);
    const cell2 = newRow.insertCell(1);
    const cell3 = newRow.insertCell(2);

    cell1.textContent = formData.name;
    cell2.textContent = formData.email;
    cell3.textContent = formData.age.toString();
}

function clearForm() {
    const form = document.getElementById('myForm') as HTMLFormElement;
    form.reset();
}
