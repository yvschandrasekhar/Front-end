function validateForm() {
    var nameInput = document.getElementById('name');
    var emailInput = document.getElementById('email');
    var ageInput = document.getElementById('age');
    var errorMessage = document.getElementById('error-message');
    errorMessage.innerText = '';
    if (!nameInput.checkValidity() || !emailInput.checkValidity() || !ageInput.checkValidity()) {
        errorMessage.innerText = 'Please fill out all the fields correctly.';
        return;
    }
    var formData = {
        name: nameInput.value,
        email: emailInput.value,
        age: parseInt(ageInput.value),
    };
    displayFormData(formData);
    clearForm();
}
function displayFormData(formData) {
    var tableBody = document.getElementById('table-body');
    var newRow = tableBody.insertRow();
    var cell1 = newRow.insertCell(0);
    var cell2 = newRow.insertCell(1);
    var cell3 = newRow.insertCell(2);
    cell1.textContent = formData.name;
    cell2.textContent = formData.email;
    cell3.textContent = formData.age.toString();
}
function clearForm() {
    var form = document.getElementById('myForm');
    form.reset();
}
