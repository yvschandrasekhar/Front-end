import { createStore } from "redux";

const initialState = {
  data: [],
  cart: [],
  wishlist:[]
}

function reducer1(state = initialState, action: { type: any, payload: any }) {
  switch (action.type) {
    case "ALL_ITEMS":
      return {...state, data: action.payload  }

    case "CART_ITEMS":
      
      const existingItemIndex=state.cart.findIndex(item=>item.id===action.payload.id)

      if (existingItemIndex===-1){
        return {...state, cart: [...state.cart, {...action.payload, quantity:1 }]}
      }else{
        state.cart[existingItemIndex].quantity += 1;
        return {...state}
      }

    case "WISHLIST_ITEMS":

      const existingWishIndex=state.wishlist.findIndex(item=>item.id===action.payload.id)
      
      if (existingWishIndex===-1){
        return {...state, wishlist: [...state.wishlist, action.payload]}
      }else{
        return state;
      }

    default: 
      return state;
  }
}

const Store = createStore(reducer1);
export default Store;






