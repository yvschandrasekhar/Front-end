const LearnmoreContainer = () => {
  return (
    <>
    <div className="learn-container">
        <h1>Shopping And Department Store.</h1>
        <p>Shopping is a bit of a relaxing hobby for me, which <br/> which is something troubling for the bank balance.</p>
        <button>Learn More</button>
    </div>
        
    </>
  )
}

export default LearnmoreContainer
