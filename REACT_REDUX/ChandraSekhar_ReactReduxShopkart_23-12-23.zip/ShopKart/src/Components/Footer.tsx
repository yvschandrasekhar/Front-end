import { useState } from "react"

const Footer = () => {

    const handleScrollToTop=()=>{
        window.scrollTo({
            top:0,
            behavior:'smooth',
        })
    }

    const [popup, setPopUp]=useState(false);
 

  return (
    <>
        <hr className="color-black mb-10"></hr>
        <div className="footer">
            <div className="footer1">
                <h3><i className="fa-solid fa-suitcase color-pink"></i>&nbsp; &nbsp;Become Seller</h3>  
                <div className="flex pointer" onClick={()=>{setPopUp(!popup);}}>
                    <h3><i className="fa-solid fa-gift color-pink"></i>&nbsp; &nbsp; Gift Cards</h3> 
                </div>
                <h3><i className="fa-solid fa-question color-pink"></i>&nbsp; &nbsp;Help Center</h3>  
            </div>
            <div className="footer2">
                <h3>Terms of Service</h3> 
                <h3>Privacy and Policy</h3>
            </div>
            <div className="footer3">
                <h3>All Right reserved by Chandu</h3>
                <h3><i onClick={handleScrollToTop} className="fa-solid fa-circle-up fa-xl color-green"></i></h3>
            </div>
        </div>   

        { popup && 
        <div className="modal">
            <div>
            <h1 className="close text-larger" onClick={()=>{setPopUp(false);}}>X</h1>
                <h2 className="color-white gift1">Here is your Gift Card :)</h2>
                <p className="color-white gift2">Y v s Chandra Sekhar</p>
            </div>
       </div> 
        }           
    </>
  )
}

export default Footer
