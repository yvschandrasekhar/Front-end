import { useDispatch, useSelector } from "react-redux"
import { Link } from "react-router-dom"

const Cart = () => {
    const cartitem=useSelector((state:any)=>state.cart)
    // console.log(cartitem,"CARTITEMS")
  return (
    <>
        <Link to={'/'}><button className="cart-home-btn">Home</button></Link>
        <div className="cart-container">
          {
            cartitem.map((item:any)=>{
              return(
                <div className="product-card">
                  <div className="card-image-container">
                      <Link to={`/products/${item.id}`} state={item}><img className="card-image" src={item.thumbnail}/></Link>
                  </div>
                  <div className="card-text-container">
                      <h3>{item.title} </h3>
                      <h3> {item.rating> 4.5 ? (<> <i className="fa-solid fa-star color-lytgreen"></i><i className="fa-solid fa-star color-lytgreen"></i> <i className="fa-solid fa-star color-lytgreen"></i> <i className="fa-solid fa-star color-lytgreen"></i> <i className="fa-solid fa-star color-lytgreen"></i></>) : (<><i className="fa-solid fa-star color-lytgreen"></i><i className="fa-solid fa-star color-lytgreen"></i><i className="fa-solid fa-star color-lytgreen"></i><i className="fa-solid fa-star color-lytgreen"></i> <i className="fa-solid fa-star-half-stroke color-lytgreen"></i></>) } (+{item.stock}) </h3>
                      <h3>M.R.P : &#8377;{item.price}/-  &nbsp; &nbsp; ({item.discountPercentage}%Off) </h3>
                      <button>BUY NOW (+{item.quantity})</button>
                  </div>
                </div>             
              )        

            })
          }
          </div>      
    </>
  )
}

export default Cart
