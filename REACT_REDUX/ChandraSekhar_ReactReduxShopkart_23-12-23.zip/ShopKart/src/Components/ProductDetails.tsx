import React from 'react'
import { useLocation } from 'react-router-dom'

const ProductDetails = () => {
    const location=useLocation();
    const product=location.state
    
  return (
    <>

      <div className="product-container2">
        <div className="product-image-container2">
          <img className="product-image2" src={product.thumbnail} alt="Product Image"/>
          <div className="thumbnail-images2">
            <img className="thumbnail-image2" src={product.images[0]} alt="Thumbnail 1"/>
            <img className="thumbnail-image2" src={product.images[1]} alt="Thumbnail 2"/>
            <img className="thumbnail-image2" src={product.images[2]} alt="Thumbnail 3"/>
            <img className="thumbnail-image2" src={product.images[3]} alt="Thumbnail 4"/>
            <img className="thumbnail-image2" src={product.images[4]} alt="Thumbnail 5"/>
          </div>
        </div>
        <div className="product-details2">
          <div className="product-title2">{product.title}</div>
          <div className="product-rating2 color-green"><li className='color-green'> {product.rating> 4.5 ? (<> <i className="fa-solid fa-star color-lytgreen"></i><i className="fa-solid fa-star color-lytgreen"></i> <i className="fa-solid fa-star color-lytgreen"></i> <i className="fa-solid fa-star color-lytgreen"></i> <i className="fa-solid fa-star color-lytgreen"></i></>) : (<><i className="fa-solid fa-star color-lytgreen"></i><i className="fa-solid fa-star color-lytgreen"></i><i className="fa-solid fa-star color-lytgreen"></i><i className="fa-solid fa-star color-lytgreen"></i> <i className="fa-solid fa-star-half-stroke color-lytgreen"></i></>) } (+{product.stock}) </li>
</div>
          <div className="product-description2">
            {product.description}
          </div>
          <div className="product-stock2">In Stock: {product.stock}</div>
          <button className="buy-now-btn2">Buy Now</button>
        </div>
      </div>
      
    </>
      
  )
}

export default ProductDetails
