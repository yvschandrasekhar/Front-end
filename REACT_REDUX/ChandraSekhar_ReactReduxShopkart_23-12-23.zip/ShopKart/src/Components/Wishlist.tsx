import { useDispatch, useSelector } from "react-redux"
import { Link } from "react-router-dom"

const WishList = () => {
    const cartitem1=useSelector((state:any)=>state.wishlist)
    console.log(cartitem1,"CARTITEMS")
  return (
    <>
        <Link to={'/'}><button className="wish-home-btn">Home</button></Link>
        <div className="wishlist">
          {
            cartitem1.map((item:any)=>{
              return(
                <div className="wishlist-product-card">
                  <div className="wishlist-image-container">
                      <img className="card-image" src={item.thumbnail}/>
                      <Link to={`/products/${item.id}`} state={item}><button className="wish-btn">Click Here For Details</button></Link>
                  </div>
                  <div className="wishlist-text-container">
                      <h3>{item.title} </h3>
                      <h3> {item.rating> 4.5 ? (<> <i className="fa-solid fa-star color-lytgreen"></i><i className="fa-solid fa-star color-lytgreen"></i> <i className="fa-solid fa-star color-lytgreen"></i> <i className="fa-solid fa-star color-lytgreen"></i> <i className="fa-solid fa-star color-lytgreen"></i></>) : (<><i className="fa-solid fa-star color-lytgreen"></i><i className="fa-solid fa-star color-lytgreen"></i><i className="fa-solid fa-star color-lytgreen"></i><i className="fa-solid fa-star color-lytgreen"></i> <i className="fa-solid fa-star-half-stroke color-lytgreen"></i></>) } (+{item.stock}) </h3>
                      <h3 className="text-large color-black">M.R.P : &#8377;{item.price}/-  &nbsp; &nbsp; ({item.discountPercentage}%Off) </h3>
                      <button className="text-small add-to-cart-btn bg-pink">WISH LISTED</button>
                  </div>
                </div>             
              )        

            })
          }
          </div>      
    </>
  )
}

export default WishList
