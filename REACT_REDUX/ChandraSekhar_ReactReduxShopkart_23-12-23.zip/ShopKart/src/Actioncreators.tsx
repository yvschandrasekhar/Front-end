export const allitems = (alldata: any) => {
    return { type: "ALL_ITEMS", payload: alldata }
}

export const allcartitems= (cartdata:any) =>{
    return { type: "CART_ITEMS", payload:cartdata} 
}


export const wishlstitems = (wishlist:any)=> {
    return { type:"WISHLIST_ITEMS", payload:wishlist}
}


// export const gadgets = (gadgetdata:any) =>{
//     return {type:"GADGET_ITEMS",payload:gadgetdata}
// }

