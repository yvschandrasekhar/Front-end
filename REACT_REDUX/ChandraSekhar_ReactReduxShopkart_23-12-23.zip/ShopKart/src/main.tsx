import ReactDOM from 'react-dom/client'
import './CSS/Header.css'
import './CSS/Navbar.css'
import './CSS/Learnmore.css'
import './CSS/Product.css'
import './CSS/Pay.css'
import './CSS/footer.css'
import './CSS/Wish.css'
import './CSS/cart.css'
import './CSS/MyAccount.css'
import { RouterProvider } from 'react-router-dom'
import AppRoute from './Components/Routes.tsx'
import { Provider } from 'react-redux'
import Store from './Store.tsx'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <Provider store={Store}>
    <RouterProvider router={AppRoute}/>
  </Provider>

)
