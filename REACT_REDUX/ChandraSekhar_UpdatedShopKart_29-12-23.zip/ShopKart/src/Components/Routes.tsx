import { createBrowserRouter } from 'react-router-dom';
import App from '../App';
import ShoppingCart from './ShoppingCart';
import MyAccount from './MyAccount';
import ProductDetails from './ProductDetails';
import Cart from './Cart';
import WishList from './Wishlist';

const AppRoute = createBrowserRouter([
    {
        path:'/',
        element:<App/>,
        children:[
            {
                path:'/',
                element:<ShoppingCart/>,
            },
            {
                path:'/account',
                element:<MyAccount/>,
            },
            {
                path:'/products/:id',
                element:<ProductDetails/>
            },
            {
                path:'/cart',
                element:<Cart/>
            },
            {
                path:'/wishlist',
                element:<WishList/>
            }

        ]
    }
])

export default AppRoute;
