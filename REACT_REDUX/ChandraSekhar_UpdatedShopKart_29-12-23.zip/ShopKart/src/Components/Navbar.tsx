import { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link } from 'react-router-dom'
import { allitems } from '../Actioncreators';
const Navbar = () => {
    const dispatch=useDispatch();
    const cartitem=useSelector((state:any)=>state.cart)
    const searchitem=useSelector((state:any)=>state.data)
    const [search,setSearch]=useState('')

    const handleSearch = () =>{
        let Searched=(
            searchitem.filter((item:any) =>
            item.title.toLowerCase().includes(search.toLocaleLowerCase()))
        )
        dispatch(allitems(Searched))
    }

  return (
    <>
    <div className='navbar'>
        <div className='navbar-item1'>
            <h1 className='text-larger'><i className="fa-solid fa-cart-shopping color-green text-larger"></i>ShopCart</h1>
        </div>

        <div className='navbar-item2'>
            
                <h3>
                <select>
                    <option><h3>Category</h3></option>
                </select> 
                </h3>
                <h3>Deals</h3>
                <Link to={'/wishlist'}><h3>Wishlist</h3></Link> 
                <h3>Delivery</h3>
            <h3 className='icon-container'>
                <input value={search} onChange={(e)=>{setSearch(e.target.value)}} className='icon-search' type='search' placeholder="Search Product" name="search"/>
                <button onClick={handleSearch}>search</button>
            </h3>
            <h3 className='Nav-btn'>
            <Link to={'./account'}><button><i className="fa-solid fa-user-tie color-black"></i> Account</button></Link>
            <Link to={'./cart'} ><button><i className="fa-solid fa-cart-plus fa-sm"></i> Cart <sup>{cartitem.length}</sup></button></Link>
            </h3>
        </div>

        
    </div>              
    </>
  )
}

export default Navbar
