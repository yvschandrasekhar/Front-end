import Header from './Header'
import LearnmoreContainer from './LearnmoreContainer'
import Navbar from './Navbar'
import Payments from './Payments'
import Products from './Products'
import Footer from './Footer'

const ShoppingCart = () => {
  return (
    <div>
        <Header/>
        <Navbar/> 
        <LearnmoreContainer/> 
        <Products/>
        <Payments/>
        <Footer/>
    </div>
  )
}

export default ShoppingCart
