import axios from "axios"
import { useEffect, useMemo, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { allcartitems, allitems, wishlstitems } from "../Actioncreators"
import { Link } from "react-router-dom"

const Products = () => {
  const [category, setCategoryData]= useState('')
  const [sortby, setSortBy]= useState('')
  const [clicked,setClicked]=useState({ allitems:true, gadgets:false, toys:false, education:false, beauty:false, fitness:false, furniture:false, sneakers:false, fashion:false });
  
  const [error,setError]=useState('')

  const dispatch=useDispatch()

  useEffect(()=>{
    axios.get(`https://dummyjson.com/products/${category}`).then((response)=>{
      // setSortedProduct(response.data.products)
      dispatch(allitems(response.data.products))
    }).catch(()=>{
      setError("Error")
    })
  }, [category,setCategoryData])

  const products =useSelector((state:any) =>state.data)

  const handleSortProducts = useMemo(() => {
      let sortedProducts=[...products]
      if (sortby==="NAME"){
          sortedProducts.sort((a,b)=>a.title.localeCompare(b.title))
          return dispatch(allitems(sortedProducts))
      } else if (sortby==="PRICE"){
          sortedProducts.sort((a,b)=>a.price-b.price)
          return dispatch(allitems(sortedProducts))
      }else{
        return dispatch(allitems(sortedProducts))       

      }
      
  },[sortby])

  return (
    <>
      <div className="category">
            <h2>Today Best Deals For You!</h2>
            <div className="category-item1">
                <button onClick={()=>{setCategoryData(""); setClicked((prev)=>({...prev, allitems:true, gadgets:false, toys:false, education:false, beauty:false, fitness:false, furniture:false, sneakers:false, fashion:false})); } }>All Items</button>
                <button onClick={()=>{setCategoryData('/category/automotive'); setClicked((prev)=>({...prev,  allitems:false, gadgets:true, toys:false, education:false, beauty:false, fitness:false, furniture:false, sneakers:false, fashion:false,})); }}>Gadgets</button>
                <button onClick={()=>{setCategoryData('/category/lighting');  setClicked((prev)=>({...prev, allitems:false, gadgets:false, toys:true, education:false, beauty:false, fitness:false, furniture:false, sneakers:false, fashion:false}));}} >Toys</button>
                <button onClick={()=>{ setCategoryData('/category/laptops');  setClicked((prev)=>({...prev, allitems:false, gadgets:false, toys:false, education:true, beauty:false, fitness:false, furniture:false, sneakers:false, fashion:false})); }}>Education</button>
                <button onClick={()=>{setCategoryData('/category/fragrances');  setClicked((prev)=>({...prev, allitems:false, gadgets:false, toys:false, education:false, beauty:true, fitness:false, furniture:false, sneakers:false, fashion:false})); }}>Beauty</button>
                <button onClick={()=>{setCategoryData('/category/groceries');  setClicked((prev)=>({...prev, allitems:false, gadgets:false, toys:false, education:false, beauty:false, fitness:true, furniture:false, sneakers:false, fashion:false}));}} >Fitness</button>
                <button onClick={()=>{setCategoryData('/category/furniture');  setClicked((prev)=>({...prev, allitems:false, gadgets:false, toys:false, education:false, beauty:false, fitness:false, furniture:true, sneakers:false, fashion:false}));}} >Furniture</button>
                <button onClick={()=>{setCategoryData('/category/mens-shoes');  setClicked((prev)=>({...prev, allitems:false, gadgets:false, toys:false, education:false, beauty:false, fitness:false, furniture:false, sneakers:true, fashion:false}));}} >Sneakers</button>
                <button onClick={()=>{setCategoryData('/category/womens-dresses');  setClicked((prev)=>({...prev, allitems:false, gadgets:false, toys:false, education:false, beauty:false, fitness:false, furniture:false, sneakers:false, fashion:true}));}} >Fashion</button> 
                <div className="sort-category">
                    <select className="btn" onClick={(e)=>{setSortBy(e.target.value), handleSortProducts();}}>
                      <option>Sort By</option>
                      <option value={"NAME"} >Name (A-Z)</option>
                      <option value={"PRICE"}>Price</option>
                    </select>
                </div>
            </div>
      </div>
      
          
          <div className="product-container">
          {
            products.map((item:any)=>{
              return(
                <div className="product-card">
                  <button className="heart-icon" onClick={()=>{dispatch(wishlstitems(item))}}><i className="fa-regular fa-heart color-black heart"></i></button>
                  <div className="card-image-container">
                      <Link to={`/products/${item.id}`} state={item}><img className="card-image" src={item.thumbnail}/></Link>
                  </div>
                  <div className="card-text-container">
                      <h3>{item.title}</h3>
                      <h3> {item.rating> 4.5 ? (<> <i className="fa-solid fa-star color-lytgreen"></i><i className="fa-solid fa-star color-lytgreen"></i> <i className="fa-solid fa-star color-lytgreen"></i> <i className="fa-solid fa-star color-lytgreen"></i> <i className="fa-solid fa-star color-lytgreen"></i></>) : (<><i className="fa-solid fa-star color-lytgreen"></i><i className="fa-solid fa-star color-lytgreen"></i><i className="fa-solid fa-star color-lytgreen"></i><i className="fa-solid fa-star color-lytgreen"></i> <i className="fa-solid fa-star-half-stroke color-lytgreen"></i></>) } (+{item.stock}) </h3>
                      <h3>M.R.P : {item.price}/-  &nbsp; &nbsp; ({item.discountPercentage}%Off) </h3>
                      <button className="card-text-container-btn" onClick={()=>{dispatch(allcartitems(item))}}>ADD TO CART </button>
                  </div>
                </div>             
              )        

            })
          }
          </div>

         
         
    </>
  )
}

export default Products
