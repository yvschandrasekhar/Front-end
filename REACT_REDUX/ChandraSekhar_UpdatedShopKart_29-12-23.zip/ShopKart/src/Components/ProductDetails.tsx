import React from 'react'
import { useLocation } from 'react-router-dom'
import { Link } from 'react-router-dom';
const ProductDetails = () => {
    const location=useLocation();
    const product=location.state
    
  return (
    <>

      <div className="product-details">
        <div className="product-details1">
          <img src={product.thumbnail} alt="Product Image"/>
          <div className="product-details2">
            <h3>{product.title}</h3>
            <h3>{product.rating> 4.5 ? (<> <i className="fa-solid fa-star color-lytgreen"></i><i className="fa-solid fa-star color-lytgreen"></i> <i className="fa-solid fa-star color-lytgreen"></i> <i className="fa-solid fa-star color-lytgreen"></i> <i className="fa-solid fa-star color-lytgreen"></i></>) : (<><i className="fa-solid fa-star color-lytgreen"></i><i className="fa-solid fa-star color-lytgreen"></i><i className="fa-solid fa-star color-lytgreen"></i><i className="fa-solid fa-star color-lytgreen"></i> <i className="fa-solid fa-star-half-stroke color-lytgreen"></i></>) } (+{product.stock})
            </h3>
            <h3>
            {product.description}
            </h3>
            <h3 className="product-stock2">In Stock: {product.stock}</h3>
            <Link to={"/cart"}><button>Go to Cart</button></Link>
          </div>
        </div>
        <h2>Similar images</h2>
        <div className="thumbnail">
            <img src={product.images[0]} alt="Thumbnail 1"/>
            <img src={product.images[1]} alt="Thumbnail 2"/>
            <img src={product.images[2]} alt="Thumbnail 3"/>
            <img src={product.images[3]} alt="Thumbnail 4"/>
            <img src={product.images[4]} alt="Thumbnail 5"/>
        </div>
      </div>
      
    </>
      
  )
}

export default ProductDetails
