
import { useSelector, useDispatch } from 'react-redux';
import { Link } from 'react-router-dom';
import Header from './Header';
import Navbar from './Navbar';
import { incrementItem, decrementItem ,removeItem } from '../Actioncreators';
 
const Cart = () => {
  const dispatch = useDispatch();
  const cartItems = useSelector((state: any) => state.cart);
 
  const handleIncrement = (productId: string) => {
    dispatch(incrementItem(productId));
  };
 
  const handleDecrement = (productId: string) => {
    dispatch(decrementItem(productId));
  };

  const handleRemove = (productId: string) => {
    dispatch(removeItem(productId));
  };
 
  const groupedCartItems: { [key: string]: any[] } = {};
  cartItems.forEach((item: any) => {
    if (!groupedCartItems[item.category]) {
      groupedCartItems[item.category] = [];
    }
    groupedCartItems[item.category].push(item);
  });
  
  const getTotalAmount = () => {
    return cartItems.reduce((total, item) => total + item.price * item.quantity, 0);
  };


  return (
    <>
      <Header />
      <Navbar />
      <div className='cart-first'>
        <Link to={"/"}>
          <button className="cart-home-btn">Home</button>
        </Link>
        <button className="total-amount">Total Amount: &#8377;{getTotalAmount()}/-</button>
        <button className='buy-btn'onClick={()=>alert('Your all items Purchased')}>Click here to purchase all items </button>
      </div>
      <div className="cart-container">
        {Object.keys(groupedCartItems).map((category) => (
          <div className='cart-container--body' key={category}>
            {/* <h2>{category}</h2> */}
            {groupedCartItems[category].map((item: any) => (
              
              <div className="product-card" key={item.id}>
                <div className="card-image-container">
                  <Link to={`/products/${item.id}`} state={item}>
                    <img className="card-image" src={item.thumbnail} alt="" />
                  </Link>
                </div><br></br>
                <div className="card-text-container">
                <button className='buy-btn'onClick={()=>alert('Click on Image')}>MORE DETAILS</button>
                  <h3>{item.title}</h3>
                  <h3>
                    {item.rating > 4.5 ? (
                      <>
                        {' '}
                        <i className="fa-solid fa-star color-lytgreen"></i>
                        <i className="fa-solid fa-star color-lytgreen"></i>{' '}
                        <i className="fa-solid fa-star color-lytgreen"></i>{' '}
                        <i className="fa-solid fa-star color-lytgreen"></i>{' '}
                        <i className="fa-solid fa-star color-lytgreen"></i>
                      </>
                    ) : (
                      <>
                        <i className="fa-solid fa-star color-lytgreen"></i>
                        <i className="fa-solid fa-star color-lytgreen"></i>
                        <i className="fa-solid fa-star color-lytgreen"></i>
                        <i className="fa-solid fa-star color-lytgreen"></i>{' '}
                        <i className="fa-solid fa-star-half-stroke color-lytgreen"></i>
                      </>
                    )}{' '}
                    (+{item.stock}){' '}
                  </h3>
                  <h3>
                    M.R.P : &#8377;{item.price}/- &nbsp; &nbsp; ({item.discountPercentage}%Off){' '}
                  </h3>
                  <h3>Quantity: {item.quantity}</h3>
                  <button className='price-btn'>Total Price: &#8377;{item.price * item.quantity}</button>
                  <div className="card-text-container--btn">
                    <button onClick={() => handleDecrement(item.id)}>DEC items</button> &nbsp; &nbsp; &nbsp; &nbsp;
                    <button onClick={() => handleIncrement(item.id)}>ADD items</button>
                  </div>
                  <div className='cart-main-btns'>
                    <button className='buy-btn'onClick={()=>alert('Your item Purchased')}>BUY NOW </button> &nbsp; &nbsp; &nbsp; &nbsp;
                    <button className='rem-btn'onClick={() => handleRemove(item.id)}>REMOVE</button>
                  </div><br></br><br></br>
                </div>
              </div>
            ))}
          </div>
        ))}
      </div>
      
    </>
  );
};
 
export default Cart;


