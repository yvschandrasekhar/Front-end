const Payments = () => {
  return (
    <>
        <div className="payment">
        <div className="payment--ele1">
            <h1><i className="fa-solid fa-cart-shopping color-green text-larger"></i>ShopKart</h1><br></br><br></br>
            <span>shopkart shopkart shopkart shopkart shopkart <br></br>shopkart shopkart shopkart shopkart shopkart <br></br>shopkart shopkart shopkart shopkart shopkart </span><br></br><br></br>
            <h3>Accepted Payments</h3><br></br><br></br>
            <h3 className="payment--ele1--item">
                <i className="fa-brands fa-stripe fa-2xl"></i> &nbsp; &nbsp;
                <i className="fa-brands fa-cc-visa fa-2xl"></i> &nbsp; &nbsp;
                <i className="fa-brands fa-cc-mastercard fa-2xl"></i> &nbsp; &nbsp;
                <i className="fa-brands fa-amazon fa-2xl"></i> <br></br><br></br> &nbsp; &nbsp;
                <i className="fa-brands fa-apple-pay fa-2xl"></i> &nbsp; &nbsp;
                <i className="fa-brands fa-google-pay fa-2xl"></i> &nbsp; &nbsp;
                <i className="fa-brands fa-google-pay fa-2xl"></i> &nbsp; &nbsp;
            </h3>
        </div>
        <div className="payment--ele2">
            <h2>About us</h2>
            <ul>
                <li>fashion</li>
                <li>Education product</li>
                <li>Frozen Foods</li>
                <li>Bevarages</li>
                <li>Organics</li>
                <li>Office Supplies</li>
                <li>Beauty products</li>
            </ul>
        </div>
        <div className="payment--ele3">
            <h2>Department</h2>
            <ul>
                <li>fashion</li>
                <li>Education product</li>
                <li>Frozen Foods</li>
                <li>Bevarages</li>
                <li>Organics</li>
            </ul>
        </div>
        <div className="payment--ele4">
            <h2>Services</h2>
            <ul>
                <li>fashion</li>
                <li>Education product</li>
                <li>Frozen Foods</li>
                <li>Bevarages</li>
                <li>Organics</li>
                <li>Office Supplies</li>
                <li>Beauty products</li>
                <li>Books</li>
                <li>Electronics & Gadgests</li>
                <li>Travel Accessories</li>
                <li>Fitness</li>
            </ul>                           
        </div>
        </div>
    </>
  )
}

export default Payments

