

function MyAccount()
{
    return(
        <>
           <div className="forms">
                <form className="form--register">
                    <h3>New User ? Register Here</h3><br></br><br></br>
                    Your Name   : <input  type="text"  placeholder="enter your name"/><br></br><br></br>
                    Enter Email: <input  type="text"  placeholder="name@gmail.com"/> <br></br><br></br>
                    YourMobile: <input  type="number" placeholder="Phone Number"/><br></br><br></br>
                    <button>Register</button>
                </form>

                <form className="form--Login">
                    <h3>Already register ? Login Here</h3><br></br><br></br>
                    Your Name   : <input  type="text"  placeholder="enter your name"/><br></br><br></br>
                    Enter Email: <input  type="text"  placeholder="name@gmail.com"/> <br></br><br></br>
                    YourMobile: <input  type="number" placeholder="Phone Number"/><br></br><br></br>
                    <button>Login</button>
                </form>
            </div>
        </>
    )
}
export default MyAccount