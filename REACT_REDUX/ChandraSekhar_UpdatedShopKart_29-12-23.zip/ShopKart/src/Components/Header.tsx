import React from 'react'
import { Link } from 'react-router-dom'

const Header = () => {
    const LangCount ={
        language: ['English','Spanish','French', 'German', 'Mandarin Chinese', 'Arabic', 'Hindi'],
        countries : ['India','America','Australlia','UK']
    }

  return (
    <>
        <div className='header'>
            <div className='header-item1'><Link to={"tel:+" +9346707687 }> <li><li className='color-white text-large'><i className="fa-solid fa-phone call-icon text-large"></i> +91 9346707687</li></li> &nbsp; &nbsp;  </Link> </div>
            <div className='header-item2'><li>Get 50% Off on Selected Items</li> &nbsp; <li className='color-white text-larger'>|</li> &nbsp; <li className='color-white text-large'>Shop Now</li> </div>
            <div className='header-item3'>
                <li>
                    <select className='bg-trans border-none color-white text-large'>
                        {
                        LangCount.language.map((item)=>{
                            return(
                                <option className='color-black'>{item}</option>
                            )
                        })
                        }
                    </select>
                </li>
                &nbsp; &nbsp;
                <li>
                    <select className='bg-trans border-none color-white text-large'>
                    {
                        LangCount.countries.map((item)=>{
                            return(
                                <option className='color-black'>{item}</option>
                            )
                        })
                        }
                    </select>
                </li>
            </div>
        </div>
    </>
  )
}

export default Header
