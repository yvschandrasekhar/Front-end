
import { createStore, Reducer } from "redux";
import { INCREMENT_ITEM, DECREMENT_ITEM } from "./Actioncreators";

interface Product {
  id: string;
  quantity:number
}

interface AppState {
  data: Product[];
  cart: Product[];
  wishlist: Product[];
}

const initialState: AppState = {
  data: [],
  cart: [],
  wishlist: [],
};

const MAX_QUANTITY = 10;
const MIN_QUANTITY = 1;

type Action = {
  type: string;
  payload: any; // Update this to a more specific type if possible
};

const reducer1: Reducer<AppState, Action> = (state = initialState, action) => {
  switch (action.type) {
    case "ALL_ITEMS":
      return { ...state, data: action.payload };

    case "CART_ITEMS":
      const existingItemIndex = state.cart.findIndex((item) => item.id === action.payload.id);

      if (existingItemIndex === -1) {
        return { ...state, cart: [...state.cart, { ...action.payload, quantity: 1 }] };
      } else {
        const updatedQuantity = state.cart[existingItemIndex].quantity + 1;
        const newQuantity = Math.min(MAX_QUANTITY, updatedQuantity);

        state.cart[existingItemIndex].quantity = Math.max(MIN_QUANTITY, newQuantity);

        return { ...state };
      }

    case "WISHLIST_ITEMS":
      const existingWishIndex = state.wishlist.findIndex((item) => item.id === action.payload.id);

      if (existingWishIndex === -1) {
        return { ...state, wishlist: [...state.wishlist, action.payload] };
      } else {
        return state;
      }

    case INCREMENT_ITEM:
      return {
        ...state,
        cart: state.cart.map((item) =>
          item.id === action.payload ? { ...item, quantity: Math.min(MAX_QUANTITY, item.quantity + 1) } : item
        ),
      };

    case DECREMENT_ITEM:
      return {
        ...state,
        cart: state.cart.map((item) =>
          item.id === action.payload ? { ...item, quantity: Math.max(MIN_QUANTITY, item.quantity - 1) } : item
        ),
      };

    case 'REMOVE_ITEM':
    const updatedCart = state.cart.filter((item) => item.id !== action.payload);
    return {
      ...state,
      cart: updatedCart,
    };


    default:
      return state;
  }
};

const Store = createStore(reducer1);
export default Store;
