// export const allitems = (alldata: any) => {
//     return { type: "ALL_ITEMS", payload: alldata }
// }

// export const allcartitems= (cartdata:any) =>{
//     return { type: "CART_ITEMS", payload:cartdata} 
// }


// export const wishlstitems = (wishlist:any)=> {
//     return { type:"WISHLIST_ITEMS", payload:wishlist}
// }




// export const gadgets = (gadgetdata:any) =>{
//     return {type:"GADGET_ITEMS",payload:gadgetdata}
// }

export const INCREMENT_ITEM = 'INCREMENT_ITEM';
export const DECREMENT_ITEM = 'DECREMENT_ITEM';

export const incrementItem = (productId: string) => ({
  type: INCREMENT_ITEM,
  payload: productId,
});

export const decrementItem = (productId: string) => ({
  type: DECREMENT_ITEM,
  payload: productId,
});

export const allitems = (alldata: any) => {
  return { type: "ALL_ITEMS", payload: alldata };
};

export const allcartitems = (cartdata: any) => {
  return { type: "CART_ITEMS", payload: cartdata };
};

export const wishlstitems = (wishlist: any) => {
  return { type: "WISHLIST_ITEMS", payload: wishlist };
};


export const removeItem = (productId: string) => ({
    type: 'REMOVE_ITEM',
    payload: productId,
  });
  