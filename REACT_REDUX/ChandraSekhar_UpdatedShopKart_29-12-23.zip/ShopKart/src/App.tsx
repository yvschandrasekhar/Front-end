import axios from 'axios'
import { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { allitems } from './Actioncreators'
import './App.css'
import { Outlet } from 'react-router-dom'

function App() {
  const data = useSelector((state:any) => state.data)
  const dispatch = useDispatch()
  useEffect(() => {
    axios.get('https://dummyjson.com/products').then((response) => {
      dispatch(allitems(response.data.products))
    }).catch(() => {
      console.log('error');

    })
  }, [])



  console.log('fetched',data);


  return (
    <>
      <Outlet />
    </>
  )
}

export default App
