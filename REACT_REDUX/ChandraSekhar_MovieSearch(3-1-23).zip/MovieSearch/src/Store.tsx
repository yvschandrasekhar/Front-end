import React from 'react'
import { createStoreHook } from 'react-redux'
import { createStore } from 'redux';
import { AllGenreReduceritems, Allsearchreduceritems } from './Reducers';
import { Allsearchitems } from './Actions';
import { combineReducers } from "redux";

const Allreducers=combineReducers({Allgenreitems:AllGenreReduceritems,Allsearcheditems:Allsearchreduceritems})


const store=createStore(Allreducers,
    window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
    )

export default store    