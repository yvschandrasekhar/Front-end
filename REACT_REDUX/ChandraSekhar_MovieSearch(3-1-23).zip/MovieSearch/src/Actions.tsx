export const ALLGENREITEMS ='ALLGENREITEMS'
export const ALLSEARCHITEMS="ALLSEARCHITEMS"
export const Allgenreitems=(data: any)=>{
   return{
    type:ALLGENREITEMS,
    payload:data
   }
}

export const Allsearchitems=(data)=>{
    return{
        type:ALLSEARCHITEMS,
        payload:data
    }
}