import React from 'react'
import { useSelector } from 'react-redux'
import Navbar from './Navbar'

const Display = () => {
    const Displaygenreitems=useSelector((state:any)=>state.Allgenreitems.genreitems)
    
  return (
    <div className='movie-container'>
    {Displaygenreitems.map((item, index) => (
      <div key={index} className='movie-card'>
        <p className='title-name'>{item.title}</p>
        <img className='image' src={item.posterURL}/>
      </div>
    ))}
  </div>  
  )
}

export default Display
