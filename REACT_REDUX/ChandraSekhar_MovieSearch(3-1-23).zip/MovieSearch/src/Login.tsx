import axios from 'axios'
import React, { useState } from 'react'
import { useNavigate } from 'react-router'
import { Link } from 'react-router-dom'

const Login = () => {
    const [email,setemail]=useState("")
    const [password,setpassword]=useState("")
    const navigate=useNavigate()
    const handleapi=()=>{
           
            axios.post("https://reqres.in/api/login",{
                    email:email,
                    password:password
            })
            .then((response)=>{
                console.log(response.data)
                localStorage.setItem('token',response.data.token)
                navigate("/")
            })
            .catch((error)=>{
                console.log(error)
            })

    }
    return (
      <div className="login-form">
        <h1>Login</h1>
        <div className="input-group">
          <label>Email:</label>
          <input
            type='text'
            value={email}
            onChange={(e) => setemail(e.target.value)}
          />
        </div>
        <div className="input-group">
          <label>Password:</label>
          <input
            type='password'
            value={password}
            onChange={(e) => setpassword(e.target.value)}
          />
        </div>
        <button onClick={handleapi}>LOGIN</button>
      </div>
    );
}

export default Login
