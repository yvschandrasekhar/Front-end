import React, { useEffect } from 'react'
import { useNavigate } from 'react-router'

const Some = () => {
    const navigate=useNavigate()
   
  return (
    <div>
      <h1>some component is here</h1>
    </div>
  )
}

export default Some
