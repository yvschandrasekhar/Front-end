import { Link } from "react-router-dom"

function Privacy()
{
    return(
        <>
            <div className="privacy">
                <h1>EZOIC SERVICES</h1>
                <h3>This website uses the services of Ezoic Inc. Ezoic's privacy policy is here. Ezoic may employ a variety of technologies on this website, including to display advertisements and enable advertising to visitors of this website. For additional information about Ezoic's advertising partners, please see Ezoic's Advertising Partner Page <Link to={'/'}>Home</Link>.</h3>
            </div>
        </>
    )
}
export default Privacy