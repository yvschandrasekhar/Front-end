import React from 'react'
import { useSelector } from 'react-redux'

const Searchitems = () => {
    const displaysearchitems=useSelector((state:any)=>state.Allsearcheditems.movieitems)
    console.log(displaysearchitems,"search")
    if (!displaysearchitems) {
      // If displaysearchitems is undefined or null, display a message or return null
      return <p>No search results found.</p>;
  }

  return(
    <div className='movie-container'>
    {displaysearchitems.map((item:any, index:number) => (
      <div key={index} className='movie-card'>
        <p className='title-name'>{item.Title}</p>
        <img className='image' src={item.Poster}/>
      </div>
    ))}
   
  </div>
  )
}

export default Searchitems
