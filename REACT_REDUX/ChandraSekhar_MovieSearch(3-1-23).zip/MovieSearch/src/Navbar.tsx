  import axios from 'axios'
  import React, { useEffect, useRef, useState } from 'react'
  import { useDispatch } from 'react-redux'
  import { Allgenreitems, Allsearchitems } from './Actions'
  import { Link, useNavigate } from 'react-router-dom'

  const Navbar = () => {
      const [click,setclick]=useState(false)
      const href=useRef<HTMLInputElement>(null)
      const[search,setsearch]=useState(null)
      const navigate=useNavigate()
      const dispatch=useDispatch()
      const [blogClick,setBlogClick]=useState(false)
      const handlesearch=()=>{
          setclick(!click)
      }
      const handleActor=(actorname)=>{
        console.log(actorname,"actor")
        axios.get(`http://www.omdbapi.com/?i=tt3896198&apikey=727bbdc1&s=${actorname}`)

        .then((response)=>{
          dispatch(Allsearchitems(response.data.Search))
          navigate(`/searchitem`)
         
      
        })
        .catch(error=>{
          console.log(error)
        })

      }


      const handleGenre=(value: string)=>{
          axios.get(`https://api.sampleapis.com/movies/${value}`)
          .then((response)=>{
            // console.log(response.data)
            dispatch(Allgenreitems(response.data))
            
          })
          .catch(error => {
            console.log('There was an error!', error);
          });
      }
      const handleinputchange=()=>{
        setsearch(href.current?.value);
      }

      const handlesearchitem=(event)=>{
       
        if (event.key==="Enter"){
          axios.get(`http://www.omdbapi.com/?i=tt3896198&apikey=727bbdc1&s=${search}`)

          .then((response)=>{
            console.log(response.data.Search)
            dispatch(Allsearchitems(response.data.Search))
            navigate(`/searchitem`)
            setclick(false)
        
          })
          .catch(error=>{
            console.log(error)
          })
        }
     

      }
      useEffect(()=>{
        if (href.current) {
          href.current.focus();
        }
      },[])
      useEffect(()=>{
      
       handlesearchitem(event)
      },[search])


      const handleuserlogout=()=>{
        localStorage.removeItem('token')
        navigate("/login");
      }
      const handleBlogClick = () => {
        setBlogClick(true)
        navigate('/blog')
    };

    return (
      <div className='navbar'>
      <div className='navbar-left'>
        <Link to="/"><img height={65} src={"https://pickamovieforme.b-cdn.net/wp-content/uploads/2020/09/logo_c.png"}/></Link>  
      </div>
      <div className='navbar-right'>
      <div className='dropdown'>
            <h4 className='orange-underline'>TOP GENRES <i className="fa-solid fa-chevron-down"></i><span> |</span></h4>
            <ul className='top-genre-list'>
              <Link className='linkto' to='/genre'>  <li onClick={()=>handleGenre('drama')}>Drama</li></Link>
            <Link className='linkto'  to='/genre'> <li onClick={()=>handleGenre('horror')}>Horror</li></Link> 
            <Link className='linkto' to='/genre'>  <li onClick={()=>handleGenre('comedy')}>Comedy</li></Link>
            <Link className='linkto'  to='/genre'> <li onClick={()=>handleGenre('family')}>Family</li></Link> 
            <Link className='linkto' to='/genre'>  <li onClick={()=>handleGenre('mystery')}>Mystery</li></Link>
            <Link className='linkto' to='/genre'> <li onClick={()=>handleGenre('scifi-fantasy')}>Scifi-fantasy</li></Link> 
            <Link className='linkto'  to='/genre'> <li onClick={()=>handleGenre('western')}>Western</li></Link> 
            <Link className='linkto'  to='/genre'> <li onClick={()=>handleGenre('classic')}>Classic</li></Link> 
            </ul>
          </div>
          <div className='dropdown'>
          <h4 className='orange-underline'>TOP ACTORS <i className="fa-solid fa-chevron-down"></i><span> |</span></h4>

            <ul className='top-genre-list'>
            <Link className='linkto' to='/actors'>  <li onClick={()=>handleActor('NTR')}>NTR</li></Link>

            <Link className='linkto' to='/actors'>  <li onClick={()=>handleActor('Jack')}>Jack</li></Link>
            <Link className='linkto' to='/actors'>  <li onClick={()=>handleActor('Scarlett Johansson')}>Scarlett Johansson</li></Link>

            <Link className='linkto' to='/actors'>  <li onClick={()=>handleActor('Pawan')}>Pawan</li></Link>
            <Link className='linkto' to='/actors'>  <li onClick={()=>handleActor('Salman')}>Salman</li></Link>
            <Link className='linkto' to='/actors'>  <li onClick={()=>handleActor('Robert')}>Robert</li></Link>
            <Link className='linkto' to='/actors'>  <li onClick={()=>handleActor('Leonardo DiCaprio')}>Leonardo DiCaprio</li></Link>
            <Link className='linkto' to='/actors'>  <li onClick={()=>handleActor('Chris Evans')}>Chris Evans</li></Link>
            </ul>
          </div>
          <h4 onClick={handleBlogClick} className='orange-underline'>BLOG</h4>
          <h4><i className="fa-solid fa-magnifying-glass icon-search "  onClick={handlesearch}   style={{color: "#fcfcfd",}}></i></h4>
          <Link className='color-white' to={'https://www.facebook.com/'} target="_blank" ><h4><i className="fa-brands fa-facebook icon"></i></h4></Link>
          
          <Link className='color-white'  to={"https://www.instagram.com/pickamovieforme/"}  target="_blank"><h4><i className ="fa-brands fa-instagram icon"></i></h4></Link>
          <Link className='color-white'  to={"https://www.youtube.com/channel/UCLLe8pZVF_BWnPp4-TPfsTQ/" } target="_blank"><h4><i className ="fa-brands fa-youtube icon "></i></h4></Link>
          <h4 className='color-white logout' onClick={handleuserlogout}>LOGOUT</h4>
          {click? <input type='text' ref={href} placeholder='search name' className='search-icon' onChange={handleinputchange} onKeyDown={handlesearchitem}/>:''}
      </div>
      </div>
      
    )
  }

  export default Navbar
