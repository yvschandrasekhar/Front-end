import React from 'react'
import { Link } from 'react-router-dom'

const Footer = () => {
  return (
    <div>
        <div className='footer'>
            <p><i className="fa-regular fa-copyright color-gray"></i>&nbsp;&nbsp;COPY RIGHT 2023 - PICKAMOVIEORME.COM </p>
            <p> <Link to={"/contact"}>CONTACT</Link> | <Link to={"/privacy"}>PRIVACY POLICY</Link> </p>
        </div>
    </div>
  )
}

export default Footer
