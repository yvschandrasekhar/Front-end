import { useEffect, useState } from 'react'

import './App.css'
import { Outlet, useNavigate } from 'react-router'
import Navbar from './Navbar'
import Footer from './Footer'

function App() {
  const navigate=useNavigate()
  useEffect(()=>{
    if(!localStorage.getItem("token"))
    {
        navigate("/login");
    }
  })

  return (
    <div className='bg-container'>
    <Navbar/>
    <Outlet/>
    <Footer/>
    </div>
  )
}

export default App
