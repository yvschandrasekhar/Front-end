  import React, { useEffect, useState } from 'react'
  import './App.css'
  import { useDispatch } from 'react-redux'
  import { Allgenreitems } from './Actions'
  import { useNavigate } from 'react-router'
  import axios from 'axios'
  const MovieRecommendation = () => {
    const [next,setnext]=useState(false)
    const[next1,setnext1]=useState(false)
    const[next2,setnext2]=useState(false)
    const[start,setstart]=useState(true)
    const [section1,setsection1]=useState(0)
    const[sectionl,setsectionl]=useState(false)
    const [option,setoption]=useState('')
    const dispatch=useDispatch()
    const navigate=useNavigate()
    const [selectedItem, setSelectedItem] = useState(null);

    const [checkedItems,setcheckedItems]=useState({})
    const handlestart=()=>{
      setstart(false)
      setsection1(section1+1)
      setnext1(false)
    }
    const handlenext1=(value:number)=>{
      setSelectedItem(value);
      setnext(true)
    }
    const handlesubmit=()=>{
      setstart(false)
      setsection1(section1+1)
      setnext1(false)
      navigate(`/answer`)
    }
    useEffect(()=>{
      if (option) {
        axios.get(`https://api.sampleapis.com/movies/${option}`)
          .then((response) => {
            dispatch(Allgenreitems(response.data));
           
          })
          .catch(error => {
            console.log('There was an error!', error);
          });
      }
     
    
      
    },[option])

    const handleoption=(e: { target: { value: React.SetStateAction<string> } })=>{
      setoption(e.target.value)
      setnext1(true)
      setnext2(true)
    
      // console.log(e.target.value)
    }
    
    const handleGenreOption = (e: React.ChangeEvent<HTMLInputElement>) => {
      const { value, checked } = e.target;
      setcheckedItems({ ...checkedItems, [value]: checked });
    };
    return (
      <div>
        {start&&<div className='movie-recommendation'>  
          <h1 className='movie-heading'>MOVIE RECOMMENDATION ENGINE</h1>
          <h1 className='movie-para'>You can’t decide between thousands of movies available for streaming?<br/>
          Answer 6 questions and let us do the work!</h1>
          <button className='start-now' onClick={handlestart}>Start Now</button>
        </div>}
      {section1===1 && <div className='question1'>
            <div className='adv_question'>1.  How are you today?</div>
            <div className='select-emoji'>
            <li className={`list-answer ${selectedItem === 1 ? 'selected' : ''}`} onClick={() => handlenext1(1)}> <i className="fa-regular fa-face-smile"></i> Happy</li>
            <li className={`list-answer ${selectedItem === 2 ? 'selected' : ''}`} onClick={() => handlenext1(2)}> <i className="fa-regular fa-face-meh"></i> Neutral</li>
            <li className={`list-answer ${selectedItem === 3 ? 'selected' : ''}`} onClick={() => handlenext1(3)}><i className="fa-regular fa-face-frown-open"></i>Sad</li>
            </div>  
            {next&&<button className='next-button' onClick={handlestart}> Next</button>}
        </div>}
        {section1===2 &&<div>
          <div className='question2'>
            <h1 className='question2-checkbox'>2. What comes closest to your occasion?</h1>
            <li className={option === 'Just watching a movie by myself.' ? 'selected' : ''}> <input type='checkbox' value="Just watching a movie by myself." checked={option==='Just watching a movie by myself.'} onChange={handleoption} />Just watching a movie by myself. </li>
            <li className={option==='Movie Date'?'selected':""}> <input type='checkbox' value="Movie Date" checked={option==='Movie Date'}  onChange={handleoption}/>Movie Date.</li>
            <li className={option==='Movie Night with friends'?'selected':""}> <input type='checkbox' value="Movie Night with friends" checked={option==='Movie Night with friends'}  onChange={handleoption}/> Movie Night with friends.</li>
            <li className={option==='Date Night with boyfriend or girlfriend'?'selected':""}> <input type='checkbox' value="Date Night with boyfriend or girlfriend" checked={option==='Date Night with boyfriend or girlfriend'}  onChange={handleoption}/>Date Night with boyfriend or girlfriend.</li>
            <li className={option==='Watching a movie with family or relatives'?'selected':""}> <input type='checkbox' value="Watching a movie with family or relatives" checked={option==='Watching a movie with family or relatives'}  onChange={handleoption}/>Watching a movie with family or relatives.</li>
            {next1&&
            <div><button className='next-button' onClick={handlestart}> Next1</button></div>}
            </div>
        
          </div>}
      
        {section1==3 && <div className='question2 question3'>
          <h1 className='question2-checkbox'>3.Please choose any genre you’re interested in.</h1>
          <span className='multiple-ans'> Mutliple answers are possible.</span>
              <div className='d-flex'>
                  <ul className='genre-list' >
              <li > <input type='checkbox' checked={option==="drama"}    value="drama"  onChange={handleoption} /> Drama</li>
                <li > <input type='checkbox' checked={option==="horror"}    value="horror"   onChange={handleoption}/>Horror</li>
                <li> <input type='checkbox' checked={option==="comedy"} value="comedy"  onChange={handleoption}/> Comedy</li>
                <li> <input type='checkbox'  checked={option==="family"}    value="family" onChange={handleoption}/>Family</li>
            
              </ul>
              <ul  className='genre-list' >
              <li> <input type='checkbox'   checked={option==="western"} value="western"  onChange={handleoption} /> Western</li>
                <li> <input type='checkbox'  checked={option==="classic"}  value="classic"   onChange={handleoption}/>Classic</li> 
                <li> <input type='checkbox' checked={option==="scifi-fantasy"}  value="scifi-fantasy"  onChange={handleoption}/> Scifi-fantasy</li>
                <li> <input type='checkbox' checked={option==="mystery"} value="mystery"  onChange={handleoption}/>Mystery</li>

              </ul>
              </div>
              {next2&&
            <div><button className='next-button' onClick={handlestart}> Next2</button></div>}
          </div>}

        {section1===4 && <div className='question2'>
          <p className='submitpara'> All your answers are going to submit</p>
          <button className='submit-button' onClick={handlesubmit}>Submit</button>
          </div> }
      </div>
    )
  }

  export default MovieRecommendation
