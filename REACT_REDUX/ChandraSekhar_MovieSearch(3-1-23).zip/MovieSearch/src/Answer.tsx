import React from 'react'
import { useSelector } from 'react-redux'

const Answer = () => {
    
    const Displaygenreitems=useSelector((state:any)=>state.Allgenreitems.genreitems)
    const genrelength=Displaygenreitems.length
    const randomIndex = Math.floor(Math.random() * genrelength);
    const display=Displaygenreitems[randomIndex+1]
    
    return (
      <div className='movie-container'>
      {
        <div className='movie-card'>
          <p className='title-name'>{display.title}</p>
          <img className='image' src={display.posterURL}/>
        </div>
      }
    </div>  
    )
}

export default Answer
