import React from 'react'
import { createBrowserRouter } from 'react-router-dom'
import MovieApp from './MovieApp'
import App from './App'
import Display from './Display'
import Search from './Searchitems'
import Searchitems from './Searchitems'
import Answer from './Answer'
import Some from './Some'
import Login from './Login'
import Contact from './Contact'
import Privacy from './Privacy'
import Blog from './Blog'
const AppRoutes = createBrowserRouter([
    {
        path:"/",
        element:<App/>,
        children:[{
            path:"/",
            element:<MovieApp/>
        },{
            path:"/genre",
            element:<Display/>
        },
        {
            path:'/answer',
            element:<Answer/>
        },
        {
            path:"/login",
            element:<Login/>
        },
        {
            path:"/searchitem",
            element:<Searchitems/>            
        },
        {
            path:"/contact",
            element:<Contact/>
        },
        {
            path:"/privacy",
            element:<Privacy />
        },
        {
            path:"/blog",
            element:<Blog />
        }
        ]
    }
])

export default AppRoutes
