import React from 'react'
import Navbar from './Navbar'
import "./App.css"
import MovieRecommendation from './MovieRecommendation'
import Moviespage from './Moviespage'
const MovieApp = () => {
  return (
    <div className='bg-container'>
  
    <MovieRecommendation/>
    <Moviespage/>
    </div>
  )
}

export default MovieApp
