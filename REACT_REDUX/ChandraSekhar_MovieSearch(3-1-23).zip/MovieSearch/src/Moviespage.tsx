import React from 'react'

const Moviespage = () => {
  return (
    <div>
        <div className='movies-info'>
            <div >
                <h1 className='movies-info-number'>760</h1>
                <p className='movies-info-name'>MOVIES</p>
               
            </div>
            <div>
                <h1 className='movies-info-number'>20</h1>
                <p  className='movies-info-name'>GENERES</p>
            </div>
            <div>
                <h1 className='movies-info-number'>10,000+</h1>
                <p  className='movies-info-name'>ACTORS</p>
            </div>
        </div>
        <div className='moviesnote'>
           <h1 className='smart-way'>The Smart Way To Pick A Movie.</h1> 
           <h2 className='smartway'>Watching movies is fun, but figuring out what movie to watch next is a nerve-racking experience. Endlessly scrolling through Netflix, watching trailers on YouTube, looking up IMDb ratings, wasting half an hour and still cannot decide what to watch – does this seem familiar to you?

             Then you have landed on the right page! PickAMovieForMe’s movie recommendation engine is the answer to the question “What movie should I watch?”! Your film choices are about to be simplified greatly.

            Our quiz-based movie picker finds the perfect movie for your mood, occasion and individual preferences in just a few minutes! Whether you’re watching a movie by yourself, joining a movie night with friends or going on a movie date with your crush – our quiz will guide you to an awesome choice!</h2>
            <h1 className='smart-way'>What Makes This Movie Recommendation Engine Unique?</h1> 
            <h2 className='smartway'>Key Features:</h2>
                <ul className='smartway'>
                    <li>All listed movies are hand-picked and manually tagged by film connoisseurs ensuring high-quality recommendations.</li>
                    <li>Consideration of your mood and the occasion in the movie suggestion.</li>
                    <li>Watch movie trailers directly on our website.</li>
                    <li>Get only one recommendation at a time, making decision-making easier (with a button to get the next recommendation).</li>
                    <li>New movies are added consistently.</li>
                </ul>

                <ul className='smartway'>
                    <li>Special recommendations for movie dates: movies perfect for dates & impressing your crush.</li>
                    <li>Special categories: movies based on true stories or books, Spy Movies, Cop Movies, Heist Movies, Girl Power Movies, Racing Movies, Space Movies, Wedding Movies, IMDb Top 250 movies, movies set in New York, movies set in Las Vegas, movies that may change the way you look at life, etc.</li>
                </ul>
           <h2 className='giveittry'> Give it a try! if you like it , please <span className='share'> share </span> it ! if not, we highly appreciate  any kind of <span className='share'>feedback.</span></h2>             
        </div>
      
    </div>
  )
}

export default Moviespage
