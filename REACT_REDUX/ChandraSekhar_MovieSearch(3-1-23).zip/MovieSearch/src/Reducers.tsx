import { ALLGENREITEMS, ALLSEARCHITEMS } from "./Actions"


const initalstategenre={
    genreitems: []
}
const intialsearchitems={
    movieitems:[]
}


export const AllGenreReduceritems=(state=initalstategenre,action: { type: any; payload: any })=>{

    switch (action.type){
        case ALLGENREITEMS:
            return{
                ...state,
                genreitems:action.payload
            }
        default:
            return state;    
    }
        
}

export const Allsearchreduceritems=(state=intialsearchitems,action: { type: any; payload: any; })=>{
    switch(action.type){
        case ALLSEARCHITEMS:
            return{
                ...state,
                movieitems:action.payload
            }
        default:
            return state;   
            
    }
}